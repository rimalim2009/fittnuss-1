FITTNUSS
========================

This is a code for inverse analysis of tsunamis from their deposits. See details i the following paper:
Naruse, H., & Abe, T. (2017). Inverse Tsunami Flow Modeling Including Nonequilibrium Sediment Transport, With Application to Deposits From the 2011 Tohoku�]Oki Tsunami. Journal of Geophysical Research: Earth Surface, 122(11), 2159-2182.

---------------
Installation

python setup.py install

---------------
Test codes

python setup.py test

---------------
How to use FITTNUSS


